<div class="content-area pvt0">
		<div class="section-full fs-slide">
			<?php if(isset($headline) && count($headline)>0){ ?>
				<div class="swiper-container">
			    	<div class="swiper-wrapper">
			    		<?php foreach ($headline as $key => $value) { ?>			    			
				    		<div class="swiper-slide">
								<div class="fs-item" data-bg-color="#f1f1f1">
									<div class="fs-entry-bg" data-bg-image="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg"></div>
									<div class="container">
										<div class="row">
											<div class="col-md-6">
												<div class="fs-entry-item">
													<h4 class="fs-title fs-animate-text" ><?php echo isset($value['category']['name'])?$value['category']['name']:'';?></h4>
													<h3 class="fs-animate-text"><?php echo isset($value['title'])?$value['title']:'';?></h3>
		
													<a href="<?php echo url_reformat($value);?>" class="read-more fs-animate-text">Selengkapnya</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
				
				<div class="fs-arrows">
					<a href="<?php echo url_reformat($value);?>" class="fs-arrow-prev"><i class="fa fa-angle-left"></i> Prev</a>
					<a href="<?php echo url_reformat($value);?>" class="fs-arrow-next">Next <i class="fa fa-angle-right"></i></a>
				</div>
				<div class="fs-arrows arrows-bottom">
					<a href="<?php echo url_reformat($value);?>" class="fs-arrow-prev"><i class="fa fa-angle-left"></i></a>
					<a href="<?php echo url_reformat($value);?>" class="fs-arrow-next"><i class="fa fa-angle-right"></i></a>
				</div>
			<?php }else{ ?>
					<center>No Data</center>
			<?php } ?>
		</div>
		<div class="section-full pv9 pvb0">
			<div class="container">
				<div class="row sticky-parent fs-with-sidebar">
					<div class="col-sm-9 sticky-column fs-content">

						<h2 class="block-title mv5" data-title="News">
							Warta
							
						</h2>
						<?php if(isset($listberita) && count($listberita)>0){ ?>
							<div class="theiaStickySidebar">
								<div class="masonry-layout row" data-col-width=".col-sm-6">
								<div class="fs-grid-posts">
										<!-- end .fs-post-filter -->
									<?php foreach ($listberita as $key => $value) { ?>	
										<div class="fs-grid-viewport" style="position:relative;">
											<div class="col-sm-4 ">
												<div class="fs-blog-item boxed-title">
									        		<a href="<?php echo url_reformat($value);?>">
									        			<img src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg" alt="portfolio image">
									        		</a>
									        		<div class="entry-title">
									        			<h4><a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></a></h4>
									        			<p class="read-more">
									        				<a href="<?php echo url_reformat($value);?>">Selengkapnya</a>
									        			</p>
									        		</div>
									        	</div>
											</div>
										</div>
									<?php } ?>
									<!-- /.fs-grid-viewport -->
								</div>
								</div>
								<!-- /.masonry-layout -->

							</div>
						<?php }else{ ?>
							<center>No Data</center>
						<?php } ?>
						<!-- //theiaStickySidebar -->

					</div>
					<div class="col-sm-3 sticky-column fs-sidebar">
						<div class="theiaStickySidebar">
							<div class="widget widget_search" style="display:none;">
								<h5 class="widget-title">Search</h5>
								<form action="./" class="search_form" method="get">
									<input type="text" placeholder="Type your keyword" required="" name="s">
									<input type="submit" value="Search">
								</form>
							</div>
							<div class="widget">
								<h5 class="widget-title">Terpopuler</h5>
								<?php if(isset($berita_terpopuler) && count($berita_terpopuler)>0){ ?>
									<?php foreach ($berita_terpopuler as $key => $value) { ?>
									<div class="fs-recent-post">
										<div class="fs-rp-item">
				    						<div class="category-block articles trending row">
												<div class="col-xs-6 col-sm-12">
														<span class="fancy-number"><?php echo $key +1;?></span>
														<a href="<?php echo url_reformat($value);?>">
															<div class="image" >
																<img src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg" alt="Proportion"/>
															</div>
														</a>
														<h4 class="sidebar-title"><a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></a></h4>
												</div>								
											</div>	
										</div>
									</div>
									<?php } ?>
								<?php } ?>
							</div>
						</div>
						<!-- //theiaStickySidebar -->

					</div>
				</div>
			</div>
		</div>
		<div class="section-full pv9 pvb0">
			<div class="container">
				<div class="row sticky-parent fs-with-sidebar">
					<div class="col-sm-12 sticky-column fs-content">

						<div class="theiaStickySidebar">

							<div class="fs-grid-posts">
								<div class="fs-post-filter big-title">
									<h4 data-title="Analisis">Analisis</h4>
									<a href="#" class="category-more text-right hidden-xs">Continue to the category <img src="<?php echo $this->webconfig['lokapala_template']; ?>images/arrow-right.png" alt="Arrow"></a>
								</div>
								<?php if(isset($listanalisis) && count($listanalisis)>0) { ?>
								<div class="news-slider news-slider-hover mv5 mvt0">

									<!-- masterslider -->
									<div class="master-slider ms-skin-default" id="masterslider1">
									<?php foreach ($listanalisis as $key => $value) { ?>
									    <div class="ms-slide">
									    	<div class="slide-pattern"></div>
									        <img src="<?php echo $this->webconfig['lokapala_template']; ?>plugins/masterslider/style/blank.gif" data-src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg" alt="Image"/>
									        <div class="ms-thumb post">
									        	<div class="thumb-meta">
													<h4><?php echo isset($value['title'])?$value['title']:'';?></h4>
												</div>
									        </div>
									        <div class="ms-layer box" data-effect="bottom(45)" data-duration="300" data-ease="easeInOut">

												<h4><a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></a></h4>
										        <p><?php echo isset($value['summary'])?$value['summary']:'';?></p>

									        </div>
									    </div>
									<?php } ?>
									</div>
									<!-- end of masterslider -->
								</div>
								<?php } ?>
							</div>
						</div>
						<!-- //theiaStickySidebar -->
					</div>
				</div>
			</div>
		</div>
		<div class="section-full pv9">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<div class="col-md-12">
								<h2 class="block-title mv5" data-title="Multimedia">
									Video & Foto
									<a href="#" class="category-more text-right hidden-xs">Continue to the category <img src="<?php echo $this->webconfig['lokapala_template']; ?>images/arrow-right.png" alt="Arrow"></a>
								</h2>
								<?php if(isset($listvideo) && count($listvideo)>0){ ?>
									<?php foreach ($listvideo as $key => $value) { ?>
										<?php if($key == 0){ ?>
											<div class="row">
												<div class="category-block articles">
													<div class="col-md-12">
														<div class="post first text-bigger hover-dark">
															<div class="row">
																<div class="col-md-8">
																	<div class="image video-frame" data-src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg">
																		<img src="<?php echo $this->webconfig['lokapala_template']; ?>images/5x3.png" alt="Proportion"/>
																		<a class="video-player video-player-center video-player-large" href="https://www.youtube.com/watch?v=AJtDXIazrMo"></a>
																	</div>
					
																</div>
																<div class="col-md-4">
																	<h4><a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></a></h4>
																	<p><?php echo isset($value['summary'])?$value['summary']:'';?></p>
																</div>
															</div>
															
															
														</div>
													</div>
												</div>
											</div>
										<?php } ?>
									<?php } ?>

							</div>
							<?php foreach ($listvideo as $key => $value) { ?>
								<?php if($key >0){ ?>
									<?php if($key == 1){ ?>
										<div class="row">
									<?php } ?>
										<div class="col-sm-4">
											<div class="category-block articles">
								    				<div class="post hover-dark">
														<div class="image video-frame" data-src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg">
															<img src="<?php echo $this->webconfig['lokapala_template']; ?>images/5x3.png" alt="Proportion"/>
															<a class="video-player" href="https://player.vimeo.com/video/164110862"></a>
														</div>
														<h4><a href="#"><?php echo isset($value['title'])?$value['title']:'';?></a></h4>
														<p><?php echo isset($value['summary'])?$value['summary']:'';?></p>
													</div>
							    			</div>
										</div>
									<?php if($key == 3){ ?>	
										</div>
										<div class="row">
									<?php } ?>
									<?php if($key == 6){ ?>	
										</div>
									
									<?php } ?>
								<?php } ?>	
							<?php } ?>
							<?php }else{ ?>
									<center>No Data</center>
							<?php } ?>
								<!-- end article-carousel -->
				 		</div>
					</div>
				</div>
		</div>		
		<div class="section-full pv9 pvb0">
			<div class="container">
				<div class="row sticky-parent fs-with-sidebar">
					<div class="col-sm-12 sticky-column fs-content">
						<div class="theiaStickySidebar">
							<div class="fs-grid-posts">
								<div class="fs-post-filter big-title">
									<h4 data-title="Grafik">Loka Grafik</h4>
									<a href="#" class="category-more text-right hidden-xs">Continue to the category <img src="<?php echo $this->webconfig['lokapala_template']; ?>images/arrow-right.png" alt="Arrow"></a>
								</div>
								<?php if(isset($listgrafik)&& count($listgrafik)>0) { ?>
										<div class="fs-grid-viewport">
											<?php foreach ($listgrafik as $key => $value) { ?>
												<?php if($key == 0){ ?>
													<div class="row">
														<div class="col-sm-12">
															<div class="fs-grid-item fs-large">
																<div class="row">
																	<div class="col-sm-4">
																		
																<h3>
																	<a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></a>
																</h3>
																<p class="read-more">
																	<a href="<?php echo url_reformat($value);?>">Selengkapnya</a>
																</p>
																	</div>
																	<div class="col-sm-8">
																		<a href="<?php echo url_reformat($value);?>" class="fs-entry-image">
																			<img src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg" alt="portfolio image">
																		</a>
																	</div>
																	
																</div>
																
																
															</div>
														</div>
													
													</div>	
												<?php }else{ ?>
													<?php if($key == 1){ ?>
														<div class="row">
													<?php } ?>
														<div class="col-sm-4">
															<div class="fs-grid-item fs-large">
																<a href="<?php echo url_reformat($value);?>" class="fs-entry-image">
																	<img src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg" alt="portfolio image">
																</a>
																
																<h3>
																	<a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></a>
																</h3>
																<p class="read-more">
																	<a href="<?php echo url_reformat($value);?>">Selengkapnya</a>
																</p>
															</div>
														</div>
														
														
													<?php if($key == 3){ ?>	
															</div>
															<div class="row">
														<?php } ?>
														<?php if($key == 6){ ?>	
															</div>
														
														<?php } ?>
												<?php } ?>
											<?php } ?>
										</div>
								<?php }else{ ?>
										<center>No Data</center>
								<?php } ?>
							</div>
						</div>
						<!-- //theiaStickySidebar -->
					</div>
				</div>
			</div>
		</div>
</div>