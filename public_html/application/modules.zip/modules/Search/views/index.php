<div class="container">
    <div class="row">
        <div class="col-sm-12">
                  <script>
                  (function() {
                  var cx = '009880792730072060984:kqnpx0skgoc'; // Insert your own Custom Search engine ID here
                  var gcse = document.createElement('script'); gcse.type = 'text/javascript'; gcse.async = true;
                  gcse.src = (document.location.protocol == 'https' ? 'https:' : 'http:') +
                      '//www.google.com/cse/cse.js?cx=' + cx;
                  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(gcse, s);
                })();


                </script>
               <gcse:searchbox></gcse:searchbox>
                <gcse:searchresults defaultToImageSearch="true"></gcse:searchresults>
        </div>
    </div>
</div>