<div class="content-area pvt0">
	<div class="container">
        <h2 class="block-title mv5" data-title="News">
            Warta 
            <a href="" class="category-more text-right hidden-xs">Continue to the category <img src="<?php echo $this->webconfig['lokapala_template']; ?>images/arrow-right.png" alt="Arrow"></a>
        </h2>		
		<div class="row">
			<div class="col-md-12">
				<!-- template -->
				<?php if(isset($headline_berita)&& count($headline_berita)>0){ ?>
					<div class="news-slider news-block mv5 mvt0">
							<div class="master-slider ms-skin-default" id="masterslider1">  
								<?php foreach ($headline_berita as $key => $value) { ?>      
							    <div class="ms-slide" data-delay="0">
							        <img src="vendors/masterslider/style/blank.gif" data-src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg" alt="Image"/>
							        <div class="ms-thumb post hover-zoom">
							        	<div class="image" data-src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg"></div>
							        	<div class="thumb-meta">
								        	
											<h4><?php echo isset($value['title'])?$value['title']:'';?></h4>
										</div>
							        </div>							        
							        <div class="ms-layer box" data-delay="0" data-effect="bottom(45)" data-duration="300" data-ease="easeInOut">
					        
										<h4 class="animate-element" data-anim="fadeInUp"><a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></a></h4>
								        <p class="animate-element" data-anim="fadeInUp"><?php echo isset($value['summary'])?$value['summary']:'';?></p>

							        </div>

							    </div>
							    <?php } ?>
							</div>
					</div>
				<?php } ?>
				<!-- end of template -->
			</div>
			<!-- end col-md-12 -->
		</div>
		<!-- end .row -->		
    	<div class="row">
            <div class="col-md-12">
            	<?php if(isset($listcategory)&& count($listcategory)>0){ ?>
	                <div class="m-dimension-carousel" data-col="3" data-row="2">
	                    <div class="swiper-container carousel-container">
	                        <div class="swiper-wrapper">
                        		<?php foreach ($listcategory as $key => $value) { ?>
		                            <div class="swiper-slide">
		                                <div class="category-block articles">
		                                    <div class="post first">
		                                        <div class="meta">
		                                            <span class="author">Dave Clark</span>
		                                            <span class="date">2h</span>
		                                        </div>
		                                       <img src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg" class="img-berita">
		                                        <h4><a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></a></h4>
		                                        <p><?php echo isset($value['summary'])?$value['summary']:'';?>p>
		                                    </div>
		                                </div>
		                            </div>
                                <?php } ?>	
	                                                        
	                        </div>
	                    </div>
	                    <!-- end .swiper-container -->
	                </div>
                <?php }else{ ?>
                		<center>No Data</center>
                <?php } ?>
                <!-- end .m-dimension-carousel -->
            </div>
            <!-- end .col-md-12 -->
             <div class="col-md-12">
                <div class="border-line mv3"></div>
            </div>
        </div>		
	</div>
	<!-- end .container -->
</div>