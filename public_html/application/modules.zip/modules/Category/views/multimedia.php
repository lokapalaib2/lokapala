<div class="content-area pvt0">
	<div class="container">
    <?php if(isset($listcategory) && count($listcategory)>0){ ?>
    	<div class="row">
            <div class="col-sm-12">
                <?php foreach ($listcategory as $key => $value) { ?>
                     <?php if($key == 0){ ?>
                        <div class="col-md-12">
                            <h2 class="block-title mv5" data-title="Multimedia">
                                Video 
                                <a href="<?php echo url_reformat($value);?>" class="category-more text-right hidden-xs">Continue to the category <img src="<?php echo $this->webconfig['lokapala_template']; ?>images/arrow-right.png" alt="Arrow"></a>
                            </h2>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="gallery-slider movie-slider">
                                        <!-- masterslider -->
                                        <div class="master-slider ms-skin-default ms-skin-dark no-tint" id="masterslider4">

                                            <div class="ms-slide color-1">
                                                <div class="slide-pattern"></div>
                                                <img src="vendors/masterslider/style/blank.gif" data-src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg" alt="Image"/>

                                                <div class="ms-layer color-5" data-effect="fade(400)" data-origin="tl" data-delay="0" data-offset-y="70"><span class="label">Latest</span></div>                                                                
                                                <div class="ms-layer right-side" data-duration="300" data-ease="easeInOut">
                                                    
                                                    <div class="one-half animate-element movie-slider-meta" data-anim="fadeInUp">
                                                        <h3><?php echo isset($value['title'])?$value['title']:'';?></h3>
                                                        <div class="meta">
                                                            <span class="author">Dave Clark</span>
                                                            <span class="date">2h</span>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <div class="excerpt border-top animate-element" data-anim="fadeInUp"><?php echo isset($value['summary'])?$value['summary']:'';?></div>
                                                </div>

                                            </div>
                                             
                                            
                                        </div><!-- end of masterslider -->
                                    </div><!-- end of gallery-slider -->

                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <?php if($key > 0){ ?>
                         
                        <?php if($key == 1){ ?>
                        <div class="col-md-12">
                        <div class="m-dimension-carousel news-block" data-col="3" data-row="2">
                            <div class="swiper-container carousel-container">
                                <div class="swiper-wrapper">
                        <?php } ?>
                                <div class="swiper-slide">
                                    <div class="category-block articles">
                                        <div class="post hover-dark">
                                            <div class="image video-frame" data-src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg">
                                                <img src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg" alt="Proportion"/>
                                                <a class="video-player" href="https://player.vimeo.com/video/164110862"></a>
                                            </div>
                                            <div class="meta">
                                                <span class="author">Dave Clark</span>
                                                <span class="date">2h</span>
                                            </div>
                                            <h4><a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></p>
                                        </div>
                                    </div>
                                </div>
                        <?php if($key == 6){ ?>
                                    </div>
                                </div>
                            </div>
                             </div>
                        <?php } ?>
                    <?php } ?>
                   
                <?php } ?>
            </div>
        </div>
    <?php } ?>
    </div>
</div>
