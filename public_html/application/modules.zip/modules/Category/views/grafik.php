<div class="content-area pvt0">
	<div class="container">
    	<div class="section-full pv9 pvb0">
                <div class="container">
                    <?php if(isset($listcategory)&& count($listcategory)>0){ ?>
                        <div class="row sticky-parent fs-with-sidebar">
                            <div class="col-sm-12 sticky-column fs-content">

                                <div class="theiaStickySidebar">

                                    <div class="fs-grid-posts">
                                        <div class="fs-post-filter big-title">
                                            <h4 data-title="Grafik">Loka Grafik</h4>
                                           
                                        </div>
                                        <div class="fs-grid-viewport">

                                            <div class="row">
                                                <?php foreach ($listcategory as $key => $value) { ?>
                                                   <?php if($key ==0){ ?>
                                                        <div class="col-sm-12">
                                                            <div class="fs-grid-item fs-large">
                                                                <div class="row">
                                                                     <div class="col-sm-4">
                                                                        <h3>
                                                                            <a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></a>
                                                                        </h3>
                                                                        <p class="read-more">
                                                                            <a href="<?php echo url_reformat($value);?>">read the article</a>
                                                                        </p>
                                                                    </div>
                                                                    <div class="col-sm-8">
                                                                        <a href="<?php echo url_reformat($value);?>" class="fs-entry-image">
                                                                            <img src="<?php echo $this->webconfig['lokapala_template']; ?>images/no_images.jpg" alt="portfolio image">
                                                                        </a>
                                                                    </div>
                                                                   
                                                                </div>
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    <?php } ?>
                                                    <?php if($key > 0){ ?>
                                                        <div class="col-sm-4">
                                                            <div class="fs-grid-item fs-large">
                                                                <a href="<?php echo url_reformat($value);?>" class="fs-entry-image">
                                                                    <img src="<?php echo $this->webconfig['lokapala_template']; ?>images/blog/news-01.jpg" alt="portfolio image">
                                                                </a>
                                                            
                                                                <h3>
                                                                    <a href="<?php echo url_reformat($value);?>"><?php echo isset($value['title'])?$value['title']:'';?></a>
                                                                </h3>
                                                                <p class="read-more">
                                                                    <a href="<?php echo url_reformat($value);?>">read the article</a>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    <?php } ?>
                                                    
                                                <?php } ?>
                                            </div>
                                            
                                        </div>
                                    </div>

                                </div>
                                <!-- //theiaStickySidebar -->

                            </div>
                            
                        </div>
                    <?php }else{ ?>
                            <center>No Data</center>
                    <?php } ?>
                </div>
        </div>
	</div>
</div>